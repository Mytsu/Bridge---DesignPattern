
// Implementador Concreto 2

class DesenhoAPI2 implements DesenhoAPI {
    public void desenharCirculo(final double x, final double y, final double radius) {
        System.out.printf("API2.circulo em %f:%f - radius %f\n", x, y, radius);
    }
}