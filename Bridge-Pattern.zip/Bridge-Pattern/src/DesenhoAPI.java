// Implementador

interface DesenhoAPI {
    public void desenharCirculo(final double x, final double y, final double radius);
}